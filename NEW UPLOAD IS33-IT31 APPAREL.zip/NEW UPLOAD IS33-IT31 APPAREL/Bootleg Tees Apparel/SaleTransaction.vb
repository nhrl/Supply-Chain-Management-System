﻿Imports IBM.Data.DB2
Public Class SaleTransaction
    Private SaleConnection As DB2Connection
    Private OldQuantity As String
    Private Oldquan As Integer
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
        Dashboard.Show()
    End Sub

    Private Sub SaleTransaction_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            SaleConnection = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin;")
            SaleConnection.Open()
            DisplayProduct()
            DisplayCustomer()
            Timer1.Start()
            STPrice.Enabled = False
            Product.Enabled = False
            Customer.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub DisplayProduct()
        Dim CmdRefresh As DB2Command
        Dim RdrRefresh As DB2DataReader
        Dim row As String()
        Try
            CmdRefresh = New DB2Command("select * from product where productid like '%" & prodid.Text & "%'", SaleConnection)
            RdrRefresh = CmdRefresh.ExecuteReader
            Me.DataGridView1.Rows.Clear()
            While RdrRefresh.Read
                row = New String() {RdrRefresh.GetValue(0).ToString, RdrRefresh.GetChar(1).ToString, RdrRefresh.GetString(2).Trim(), RdrRefresh.GetString(3).Trim(), RdrRefresh.GetDecimal(4).ToString, RdrRefresh.GetValue(5).ToString}
                Me.DataGridView1.Rows.Add(row)
            End While
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DisplayCustomer()
        Dim CmdRefresh As DB2Command
        Dim RdrRefresh As DB2DataReader
        Dim row As String()
        Try
            CmdRefresh = New DB2Command("select * from customer where customerid like '%" & CusTID.Text & "%'", SaleConnection)
            RdrRefresh = CmdRefresh.ExecuteReader
            Me.DataGridView2.Rows.Clear()
            While RdrRefresh.Read
                row = New String() {RdrRefresh.GetValue(0).ToString, RdrRefresh.GetString(1).Trim(), RdrRefresh.GetString(2).Trim(), RdrRefresh.GetString(3).Trim(), RdrRefresh.GetString(4).Trim(), RdrRefresh.GetString(5).Trim}
                Me.DataGridView2.Rows.Add(row)
            End While
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub ProductSearch_Click(sender As Object, e As EventArgs) Handles ProductSearch.Click
        DisplayProduct()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        DisplayCustomer()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            If DataGridView1.Columns(e.ColumnIndex).Name = "press" Then
                Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
                Product.Text = row1.Cells("id").Value
                OldQuantity = row1.Cells("quantity").Value
                Oldquan = CInt(OldQuantity)
                STPrice.Text = row1.Cells("price").Value
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView2.CellContentClick
        Try
            If DataGridView2.Columns(e.ColumnIndex).Name = "click2" Then
                Dim row1 As DataGridViewRow = DataGridView2.Rows(e.RowIndex)
                Customer.Text = row1.Cells("cust").Value
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles CurrentDate.TextChanged
        CurrentDate.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim Newquantity As Integer = CInt(NewQuan.Text)
        If Oldquan = 0 Then
            MsgBox("Product Out of Stock...")
        ElseIf (Oldquan < Newquantity) Then
            MsgBox("Not Enough Product")
        ElseIf (Oldquan >= Newquantity) Then

            Dim STSubQuan As String
            Dim STsubcmd As DB2Command
            Dim OldQ As DB2Parameter
            Dim NewQ As DB2Parameter
            Dim ProductID As DB2Parameter

            Dim STadd As String
            Dim Staddcmd As DB2Command
            Dim STprodid As DB2Parameter
            Dim STcustid As DB2Parameter
            Dim STquantity As DB2Parameter
            Dim STprices As DB2Parameter
            Dim STdates As DB2Parameter

            STSubQuan = "call SubtractProductQuantity(?,?,?)"
            STsubcmd = New DB2Command(STSubQuan, SaleConnection)

            OldQ = STsubcmd.Parameters.Add("@old", DB2Type.Integer)
            OldQ.Direction = ParameterDirection.Input
            STsubcmd.Parameters("@old").Value = OldQuantity

            NewQ = STsubcmd.Parameters.Add("@new", DB2Type.Integer)
            NewQ.Direction = ParameterDirection.Input
            STsubcmd.Parameters("@new").Value = Me.NewQuan.Text

            ProductID = STsubcmd.Parameters.Add("@proid", DB2Type.Integer)
            ProductID.Direction = ParameterDirection.Input
            STsubcmd.Parameters("@proid").Value = Product.Text

            STadd = "call SalesADD(?,?,?,?,?)"
            Staddcmd = New DB2Command(STadd, SaleConnection)

            STprodid = Staddcmd.Parameters.Add("@stprod", DB2Type.Integer)
            STprodid.Direction = ParameterDirection.Input
            Staddcmd.Parameters("@stprod").Value = Me.Product.Text

            STcustid = Staddcmd.Parameters.Add("@stcusid", DB2Type.Integer)
            STcustid.Direction = ParameterDirection.Input
            Staddcmd.Parameters("@stcusid").Value = Me.Customer.Text

            STquantity = Staddcmd.Parameters.Add("@stquan", DB2Type.Integer)
            STquantity.Direction = ParameterDirection.Input
            Staddcmd.Parameters("@stquan").Value = Me.NewQuan.Text

            STprices = Staddcmd.Parameters.Add("@stprice", DB2Type.Decimal)
            STprices.Direction = ParameterDirection.Input
            Staddcmd.Parameters("@stprice").Value = Me.STPrice.Text

            STdates = Staddcmd.Parameters.Add("@stdate", DB2Type.DateTime)
            STdates.Direction = ParameterDirection.Input
            Staddcmd.Parameters("@stdate").Value = Me.CurrentDate.Text

            MsgBox("Sale Transaction Added Successfull...")
            Staddcmd.ExecuteNonQuery()
            STsubcmd.ExecuteNonQuery()
            Product.Clear()
            Customer.Clear()
            NewQuan.Clear()
            STPrice.Clear()
            CurrentDate.Clear()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        SaleTransactionList.Show()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        DisplayProduct()
        Timer1.Start()
    End Sub
End Class