﻿Imports IBM.Data.DB2
Public Class DeliveryList
    Private DeliveryListConnection As DB2Connection
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
    End Sub

    Private Sub DeliveryList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            DeliveryListConnection = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin;")
            DeliveryListConnection.Open()
            displayDeliveryList()
            Timer1.Start()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub displayDeliveryList()
        Dim CmdRefresh As DB2Command
        Dim RdrRefresh As DB2DataReader
        Dim row As String()
        Try
            CmdRefresh = New DB2Command("select * from delivery where deliveryid like '%" & deliveryid.Text & "%'", DeliveryListConnection)
            RdrRefresh = CmdRefresh.ExecuteReader
            Me.DataGridView1.Rows.Clear()
            While RdrRefresh.Read
                row = New String() {RdrRefresh.GetValue(0).ToString, RdrRefresh.GetValue(1).ToString, RdrRefresh.GetValue(2).ToString, RdrRefresh.GetString(3).ToString, RdrRefresh.GetString(4).Trim(), RdrRefresh.GetString(5).Trim}
                Me.DataGridView1.Rows.Add(row)
            End While
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        displayDeliveryList()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            If DataGridView1.Columns(e.ColumnIndex).Name = "update_stat" Then
                Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
                Dim checkstat As String
                Dim update As DB2Parameter
                Dim updateData As String
                Dim deliverid As DB2Parameter
                Dim cmd As DB2Command
                Dim defaultvalue As String = "Undelivered"
                Dim changeDefault As String = "Delivered"
                If MessageBox.Show(String.Format("Do you want to update delivery status from id:{0}", row1.Cells("delivery_id").Value), "Confirmation", MessageBoxButtons.OKCancel) = DialogResult.OK Then
                    checkstat = row1.Cells("stat").Value
                    If checkstat = "Undelivered" Then
                        updateData = "call UpdateDeliveryStat(?,?)"
                        cmd = New DB2Command(updateData, DeliveryListConnection)
                        deliverid = cmd.Parameters.Add("@id", DB2Type.Integer)
                        deliverid.Direction = ParameterDirection.Input
                        cmd.Parameters("@id").Value = row1.Cells("delivery_id").Value

                        update = cmd.Parameters.Add("stat", DB2Type.VarChar)
                        update.Direction = ParameterDirection.Input
                        cmd.Parameters("@stat").Value = changeDefault
                        cmd.ExecuteNonQuery()
                        MsgBox("Delivery Status Updated Successfully...")
                    ElseIf checkstat = "Delivered" Then
                        updateData = "call UpdateDeliveryStat(?,?)"
                        cmd = New DB2Command(updateData, DeliveryListConnection)
                        deliverid = cmd.Parameters.Add("@id", DB2Type.Integer)
                        deliverid.Direction = ParameterDirection.Input
                        cmd.Parameters("@id").Value = row1.Cells("delivery_id").Value

                        update = cmd.Parameters.Add("stat", DB2Type.VarChar)
                        update.Direction = ParameterDirection.Input
                        cmd.Parameters("@stat").Value = defaultvalue
                        cmd.ExecuteNonQuery()
                        MsgBox("Delivery Status Updated Successfully...")
                    End If
                End If
            ElseIf DataGridView1.Columns(e.ColumnIndex).Name = "Delete" Then
            Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            Dim delete As DB2Parameter
            Dim deleteData As String
            Dim cmd As DB2Command

            If MessageBox.Show(String.Format("Do you want to delete id:{0}", row1.Cells("delivery_id").Value), "Confirmation", MessageBoxButtons.OKCancel) = DialogResult.OK Then
                deleteData = "call DeliveryDelete(?)"
                cmd = New DB2Command(deleteData, DeliveryListConnection)
                delete = cmd.Parameters.Add("@delete", DB2Type.Integer)
                delete.Direction = ParameterDirection.Input
                cmd.Parameters("@delete").Value = row1.Cells("delivery_id").Value
                cmd.ExecuteNonQuery()
            End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        displayDeliveryList()
        Timer1.Start()
    End Sub
End Class