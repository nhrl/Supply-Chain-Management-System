﻿Imports IBM.Data.DB2
Public Class ProductUpdate
    Private ProductUpdateconn As DB2Connection
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub ProductUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        prodid.Enabled = False
        prodid.Text = Product.ProdID
        prodname.Text = Product.Product_Name
        prodquan.Text = Product.Quan
        prodsex.Text = Product.SexType
        prodprice.Text = Product.Price
        prodsize.Text = Product.Product_Size
        Try
            ProductUpdateconn = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin;")
            ProductUpdateconn.Open()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim SupplierAdd As String
        Dim Addcmd As DB2Command
        Dim id As DB2Parameter
        Dim sex As DB2Parameter
        Dim name As DB2Parameter
        Dim size As DB2Parameter
        Dim price As DB2Parameter
        Dim quantity As DB2Parameter

        SupplierAdd = "call ProductUpdate (?,?,?,?,?,?)"
        Addcmd = New DB2Command(SupplierAdd, ProductUpdateconn)
        id = Addcmd.Parameters.Add("@id", DB2Type.Integer)
        id.Direction = ParameterDirection.Input
        Addcmd.Parameters("@id").Value = Me.prodid.Text

        sex = Addcmd.Parameters.Add("@sex", DB2Type.Char)
        sex.Direction = ParameterDirection.Input
        Addcmd.Parameters("@sex").Value = Me.prodsex.Text

        name = Addcmd.Parameters.Add("@name", DB2Type.VarChar)
        name.Direction = ParameterDirection.Input
        Addcmd.Parameters("@name").Value = Me.prodname.Text

        size = Addcmd.Parameters.Add("@size", DB2Type.Char)
        size.Direction = ParameterDirection.Input
        Addcmd.Parameters("@size").Value = Me.prodsize.Text

        price = Addcmd.Parameters.Add("@price", DB2Type.Decimal)
        price.Direction = ParameterDirection.Input
        Addcmd.Parameters("@price").Value = Me.prodprice.Text

        quantity = Addcmd.Parameters.Add("@quantity", DB2Type.Integer)
        quantity.Direction = ParameterDirection.Input
        Addcmd.Parameters("@quantity").Value = Me.prodquan.Text

        MsgBox("Record has been Updated...")
        Addcmd.ExecuteNonQuery()
        Me.Close()
    End Sub
End Class