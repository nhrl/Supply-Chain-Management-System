﻿Imports IBM.Data.DB2
Public Class Transportation
    Public TranspoID As String
    Public TranspoName As String
    Public TranspoContact As String
    Private Dbconnection As DB2Connection

    Private Sub Transportation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
        Try
            Dbconnection = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin")
            Dbconnection.Open()
            Call DisplayTransportation()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub DisplayTransportation()
        Dim CmdRefresh As DB2Command
        Dim RdrRefresh As DB2DataReader
        Dim row As String()
        Try
            CmdRefresh = New DB2Command("select transpoid,transponame,transpocontact from transportationcompany", Dbconnection)
            RdrRefresh = CmdRefresh.ExecuteReader
            Me.DataGridView1.Rows.Clear()
            While RdrRefresh.Read
                row = New String() {RdrRefresh.GetValue(0).ToString, RdrRefresh.GetString(1).Trim(), RdrRefresh.GetString(2).Trim()}
                Me.DataGridView1.Rows.Add(row)
            End While
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
        Dashboard.Show()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        TransportationForm.Show()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            If DataGridView1.Columns(e.ColumnIndex).Name = "transedit" Then
                Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
                TranspoID = row1.Cells("transid").Value
                TranspoName = row1.Cells("Transname").Value
                TranspoContact = row1.Cells("contact").Value
                TransportationUpdate.Show()
            ElseIf DataGridView1.Columns(e.ColumnIndex).Name = "delete" Then
                Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
                Dim delete As DB2Parameter
                Dim deleteData As String
                Dim cmd As DB2Command

                If MessageBox.Show(String.Format("Do you want to delete id:{0}", row1.Cells("transid").Value), "Confirmation", MessageBoxButtons.OKCancel) = DialogResult.OK Then
                    deleteData = "call TransportDelete(?)"
                    cmd = New DB2Command(deleteData, Dbconnection)
                    delete = cmd.Parameters.Add("@delete", DB2Type.Integer)
                    delete.Direction = ParameterDirection.Input
                    cmd.Parameters("@delete").Value = row1.Cells("transid").Value
                    cmd.ExecuteNonQuery()
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        DisplayTransportation()
        Timer1.Start()
    End Sub
End Class