﻿Imports IBM.Data.DB2
Public Class SaleTransactionList
    Private SaleListConnection As DB2Connection
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
    End Sub

    Private Sub SaleTransactionList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            SaleListConnection = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin;")
            SaleListConnection.Open()
            Timer1.Start()
            DisplaySaleList()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DisplaySaleList()
        Dim CmdRefresh As DB2Command
        Dim RdrRefresh As DB2DataReader
        Dim row As String()
        Try
            CmdRefresh = New DB2Command("select * from Saletransaction", SaleListConnection)
            RdrRefresh = CmdRefresh.ExecuteReader
            Me.DataGridView1.Rows.Clear()
            While RdrRefresh.Read
                row = New String() {RdrRefresh.GetValue(0).ToString, RdrRefresh.GetValue(1).ToString, RdrRefresh.GetValue(2).ToString, RdrRefresh.GetValue(3).ToString, RdrRefresh.GetDecimal(4).ToString, RdrRefresh.GetDateTime(5).ToString, RdrRefresh.GetDecimal(6).ToString}
                Me.DataGridView1.Rows.Add(row)
            End While
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        If DataGridView1.Columns(e.ColumnIndex).Name = "Delete" Then
            Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            Dim delete As DB2Parameter
            Dim deleteData As String
            Dim cmd As DB2Command
            If MessageBox.Show(String.Format("Do you want to delete id:{0}", row1.Cells("idsale").Value), "Confirmation", MessageBoxButtons.OKCancel) = DialogResult.OK Then
                deleteData = "call SaleListDelete(?)"
                cmd = New DB2Command(deleteData, SaleListConnection)
                delete = cmd.Parameters.Add("@delete", DB2Type.Integer)
                delete.Direction = ParameterDirection.Input
                cmd.Parameters("@delete").Value = row1.Cells("idsale").Value
                cmd.ExecuteNonQuery()
            End If
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        DisplaySaleList()
        Timer1.Start()
    End Sub
End Class