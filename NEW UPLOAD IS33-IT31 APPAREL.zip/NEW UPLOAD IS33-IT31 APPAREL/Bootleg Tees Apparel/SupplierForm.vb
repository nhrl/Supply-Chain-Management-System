﻿Imports IBM.Data.DB2
Public Class SupplierForm
    Private SupFormConnection As DB2Connection
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub SupplierForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            SupFormConnection = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin")
            SupFormConnection.Open()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim SupplierAdd As String
        Dim Addcmd As DB2Command
        Dim lastname As DB2Parameter
        Dim firstname As DB2Parameter
        Dim middle As DB2Parameter
        Dim address As DB2Parameter
        Dim contact As DB2Parameter

        SupplierAdd = "call  SupplierAdd (?,?,?,?,?)"
        Addcmd = New DB2Command(SupplierAdd, SupFormConnection)

        lastname = Addcmd.Parameters.Add("lastname", DB2Type.VarChar)
        lastname.Direction = ParameterDirection.Input
        Addcmd.Parameters("@lastname").Value = Me.suplast.Text

        firstname = Addcmd.Parameters.Add("@first", DB2Type.VarChar)
        firstname.Direction = ParameterDirection.Input
        Addcmd.Parameters("@first").Value = Me.supfirst.Text

        middle = Addcmd.Parameters.Add("@middle", DB2Type.VarChar)
        middle.Direction = ParameterDirection.Input
        Addcmd.Parameters("@middle").Value = Me.supmiddle.Text

        address = Addcmd.Parameters.Add("@address", DB2Type.VarChar)
        address.Direction = ParameterDirection.Input
        Addcmd.Parameters("@address").Value = Me.supaddress.Text

        contact = Addcmd.Parameters.Add("@contact", DB2Type.VarChar)
        contact.Direction = ParameterDirection.Input
        Addcmd.Parameters("@contact").Value = Me.supcontact.Text

        MsgBox("New Record has been Added...")
        Addcmd.ExecuteNonQuery()
        Me.Close()
    End Sub
End Class