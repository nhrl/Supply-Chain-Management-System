﻿Imports IBM.Data.DB2
Public Class PurchaseTransaction
    Private OldQuantity As String
    Private PurchaseTranConnection As DB2Connection
    Private Sub PurchaseTransaction_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            PurchaseTranConnection = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin;")
            PurchaseTranConnection.Open()
            DisplayProduct()
            DisplaySupplier()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub PictureBox1_Click_1(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
        Dashboard.Show()
    End Sub

    Private Sub DisplayProduct()
        Dim CmdRefresh As DB2Command
        Dim RdrRefresh As DB2DataReader
        Dim row As String()
        Try
            CmdRefresh = New DB2Command("select productid, productsextype, productname, productsize, productquantity from product where productid like '%" & prodid.Text & "%'", PurchaseTranConnection)
            RdrRefresh = CmdRefresh.ExecuteReader
            Me.DataGridView1.Rows.Clear()
            While RdrRefresh.Read
                row = New String() {RdrRefresh.GetValue(0).ToString, RdrRefresh.GetChar(1).ToString, RdrRefresh.GetString(2).Trim(), RdrRefresh.GetString(3).Trim(), RdrRefresh.GetValue(4).ToString}
                Me.DataGridView1.Rows.Add(row)
            End While
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DisplaySupplier()
        Dim CmdRefresh As DB2Command
        Dim RdrRefresh As DB2DataReader
        Dim row As String()
        Try
            CmdRefresh = New DB2Command("select supid,suplname, supfname, supmname from Supplier where supid like '%" & supsearch.Text & "%'", PurchaseTranConnection)
            RdrRefresh = CmdRefresh.ExecuteReader
            Me.DataGridView2.Rows.Clear()
            While RdrRefresh.Read
                row = New String() {RdrRefresh.GetValue(0).ToString, RdrRefresh.GetString(1).Trim, RdrRefresh.GetString(2).Trim(), RdrRefresh.GetString(3).Trim()}
                Me.DataGridView2.Rows.Add(row)
            End While
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub ProductSearch_Click(sender As Object, e As EventArgs) Handles ProductSearch.Click
        DisplayProduct()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        DisplaySupplier()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            If DataGridView1.Columns(e.ColumnIndex).Name = "check" Then
                Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
                PTProductID.Text = row1.Cells("id").Value
                OldQuantity = row1.Cells("quantity").Value
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView2.CellContentClick
        Try
            If DataGridView2.Columns(e.ColumnIndex).Name = "check2" Then
                Dim row1 As DataGridViewRow = DataGridView2.Rows(e.RowIndex)
                PTSupplierId.Text = row1.Cells("supplierid").Value
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        Dim PTAdd As String
        Dim PTADDQ As String
        Dim PTAddcmd As DB2Command
        Dim PTAddQcmd As DB2Command
        Dim PTOldQuan As DB2Parameter
        Dim PTProdid As DB2Parameter
        Dim PTSupid As DB2Parameter
        Dim PTDate As DB2Parameter
        Dim PTQuantity As DB2Parameter
        Dim PTPrice As DB2Parameter

        PTADDQ = "call AddProductQuantity(?,?,?)"
        PTAddQcmd = New DB2Command(PTADDQ, PurchaseTranConnection)

        PTOldQuan = PTAddQcmd.Parameters.Add("@oldquan", DB2Type.Integer)
        PTOldQuan.Direction = ParameterDirection.Input
        PTAddQcmd.Parameters("@oldquan").Value = OldQuantity

        PTQuantity = PTAddQcmd.Parameters.Add("@quantity", DB2Type.Integer)
        PTQuantity.Direction = ParameterDirection.Input
        PTAddQcmd.Parameters("@quantity").Value = Me.PTquan.Text

        PTProdid = PTAddQcmd.Parameters.Add("@prodid", DB2Type.Integer)
        PTProdid.Direction = ParameterDirection.Input
        PTAddQcmd.Parameters("@prodid").Value = Me.PTProductID.Text

        PTAdd = "call  PTAdd(?,?,?,?,?)"
        PTAddcmd = New DB2Command(PTAdd, PurchaseTranConnection)

        PTProdid = PTAddcmd.Parameters.Add("@prodid", DB2Type.Integer)
        PTProdid.Direction = ParameterDirection.Input
        PTAddcmd.Parameters("@prodid").Value = Me.PTProductID.Text

        PTSupid = PTAddcmd.Parameters.Add("@supid", DB2Type.Integer)
        PTSupid.Direction = ParameterDirection.Input
        PTAddcmd.Parameters("@supid").Value = Me.PTSupplierId.Text

        PTDate = PTAddcmd.Parameters.Add("@date", DB2Type.Timestamp)
        PTDate.Direction = ParameterDirection.Input
        PTAddcmd.Parameters("@date").Value = Me.PTdatetime.Text

        PTQuantity = PTAddcmd.Parameters.Add("@quantity", DB2Type.Integer)
        PTQuantity.Direction = ParameterDirection.Input
        PTAddcmd.Parameters("@quantity").Value = Me.PTquan.Text

        PTPrice = PTAddcmd.Parameters.Add("@price", DB2Type.Decimal)
        PTPrice.Direction = ParameterDirection.Input
        PTAddcmd.Parameters("@price").Value = Me.price.Text

        MsgBox("Purchase Transaction Added Successfully...")
        PTAddQcmd.ExecuteNonQuery()
        PTAddcmd.ExecuteNonQuery()

        PTProductID.Clear()
        PTSupplierId.Clear()
        PTdatetime.Clear()
        PTquan.Clear()
        price.Clear()
        supsearch.Clear()
        prodid.Clear()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        PurchaseTransactionList.Show()
    End Sub

    Private Sub PTdatetime_TextChanged(sender As Object, e As EventArgs) Handles PTdatetime.TextChanged
        PTdatetime.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
    End Sub
End Class