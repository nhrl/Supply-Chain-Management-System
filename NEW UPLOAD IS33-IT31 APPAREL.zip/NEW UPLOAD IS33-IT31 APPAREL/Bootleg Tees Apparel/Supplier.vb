﻿Imports IBM.Data.DB2
Public Class Supplier
    Public SupplierID As String
    Public SupplierLastname As String
    Public SupplierFirstname As String
    Public MiddleName As String
    Public SupplierAddress As String
    Public SupplierContact As String

    Private Supplierconnection As DB2Connection

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
        Dashboard.Show()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        SupplierForm.Show()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            If DataGridView1.Columns(e.ColumnIndex).Name = "Edit" Then
                Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
                SupplierID = row1.Cells("supid").Value
                SupplierLastname = row1.Cells("suplast").Value
                SupplierFirstname = row1.Cells("supfirst").Value
                MiddleName = row1.Cells("supmid").Value
                SupplierAddress = row1.Cells("supadd").Value
                SupplierContact = row1.Cells("supcontact").Value
                SupplierUpdate.Show()
            ElseIf DataGridView1.Columns(e.ColumnIndex).Name = "Delete" Then
                Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
                Dim delete As DB2Parameter
                Dim deleteData As String
                Dim cmd As DB2Command

                If MessageBox.Show(String.Format("Do you want to delete id:{0}", row1.Cells("supid").Value), "Confirmation", MessageBoxButtons.OKCancel) = DialogResult.OK Then
                    deleteData = "call SupplierDelete(?)"
                    cmd = New DB2Command(deleteData, Supplierconnection)
                    delete = cmd.Parameters.Add("@delete", DB2Type.Integer)
                    delete.Direction = ParameterDirection.Input
                    cmd.Parameters("@delete").Value = row1.Cells("supid").Value
                    cmd.ExecuteNonQuery()
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Supplier_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
        Try
            Supplierconnection = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin")
            Supplierconnection.Open()
            displaySupplier()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub displaySupplier()
        Dim CmdRefresh As DB2Command
        Dim RdrRefresh As DB2DataReader

        Dim row As String()
        Try
            CmdRefresh = New DB2Command("select * from supplier", Supplierconnection)
            RdrRefresh = CmdRefresh.ExecuteReader
            Me.DataGridView1.Rows.Clear()
            While RdrRefresh.Read
                row = New String() {RdrRefresh.GetValue(0).ToString, RdrRefresh.GetString(1).Trim(), RdrRefresh.GetString(2).Trim(), RdrRefresh.GetString(3).Trim(), RdrRefresh.GetString(4).Trim(), RdrRefresh.GetString(5).Trim()}
                Me.DataGridView1.Rows.Add(row)
            End While
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        displaySupplier()
        Timer1.Start()
    End Sub
End Class