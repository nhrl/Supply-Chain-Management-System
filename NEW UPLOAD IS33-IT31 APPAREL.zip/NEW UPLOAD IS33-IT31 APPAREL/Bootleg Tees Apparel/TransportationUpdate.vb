﻿Imports IBM.Data.DB2
Public Class TransportationUpdate
    Private TransUpdateConnection As DB2Connection
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub TransportationUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        transid.Enabled = False
        Me.transid.Text = Transportation.TranspoID
        Me.transName.Text = Transportation.TranspoName
        Me.contact.Text = Transportation.TranspoContact
        Try
            TransUpdateConnection = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin")
            TransUpdateConnection.Open()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim TransportUpdate As String
        Dim Transportid As DB2Parameter
        Dim transname As DB2Parameter
        Dim contact As DB2Parameter
        Dim updatecmd As DB2Command

        TransportUpdate = "call TransportUpdate(?,?,?)"
        updatecmd = New DB2Command(TransportUpdate, TransUpdateConnection)

        Transportid = updatecmd.Parameters.Add("@id", DB2Type.Integer)
        Transportid.Direction = ParameterDirection.Input
        updatecmd.Parameters("@id").Value = Me.transid.Text

        transname = updatecmd.Parameters.Add("@name", DB2Type.VarChar)
        transname.Direction = ParameterDirection.Input
        updatecmd.Parameters("@name").Value = Me.transName.Text

        contact = updatecmd.Parameters.Add("@contact", DB2Type.VarChar)
        contact.Direction = ParameterDirection.Input
        updatecmd.Parameters("@contact").Value = Me.contact.Text

        updatecmd.ExecuteNonQuery()
        MsgBox("Record Update Successfully...")
        Me.Close()
    End Sub
End Class