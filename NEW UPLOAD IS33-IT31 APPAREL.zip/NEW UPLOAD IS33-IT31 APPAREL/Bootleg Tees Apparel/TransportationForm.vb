﻿Imports IBM.Data.DB2
Public Class TransportationForm
    Private Dbconn As Common.DbConnection
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub TransportationForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Dbconn = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin")
            Dbconn.Open()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim transAdd As String
        Dim Addcmd As DB2Command
        Dim name As DB2Parameter
        Dim contact As DB2Parameter

        transAdd = "call TransportAdd(?,?)"
        Addcmd = New DB2Command(transAdd, Dbconn)

        name = Addcmd.Parameters.Add("@name", DB2Type.VarChar)
        name.Direction = ParameterDirection.Input
        Addcmd.Parameters("@name").Value = Me.transponame.Text

        contact = Addcmd.Parameters.Add("@contact", DB2Type.VarChar)
        contact.Direction = ParameterDirection.Input
        Addcmd.Parameters("@contact").Value = Me.transpocontact.Text

        MsgBox("New Record has been Added...")
        Addcmd.ExecuteNonQuery()
        Me.Close()
    End Sub
End Class