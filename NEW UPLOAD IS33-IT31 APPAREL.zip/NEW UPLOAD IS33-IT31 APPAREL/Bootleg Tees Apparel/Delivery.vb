﻿Imports IBM.Data.DB2
Public Class Delivery
    Private DeliveryConnection As DB2Connection
    Private Sub Delivery_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            DeliveryConnection = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin;")
            DeliveryConnection.Open()
            DisplayTransaction()
            DisplayTransport()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DisplayTransaction()
        Dim CmdRefresh As DB2Command
        Dim RdrRefresh As DB2DataReader
        Dim row As String()
        Try
            CmdRefresh = New DB2Command("select * from saletransaction where saleid like '%" & Idsale.Text & "%'", DeliveryConnection)
            RdrRefresh = CmdRefresh.ExecuteReader
            Me.DataGridView1.Rows.Clear()
            While RdrRefresh.Read
                row = New String() {RdrRefresh.GetValue(0).ToString, RdrRefresh.GetValue(1).ToString, RdrRefresh.GetValue(2).ToString, RdrRefresh.GetValue(3).ToString, RdrRefresh.GetDecimal(4).ToString, RdrRefresh.GetDateTime(5).ToString, RdrRefresh.GetDecimal(6).ToString}
                Me.DataGridView1.Rows.Add(row)
            End While
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        DeliveryList.Show()
    End Sub
    Private Sub DisplayTransport()
        Dim CmdRefresh As DB2Command
        Dim RdrRefresh As DB2DataReader
        Dim row As String()
        Try
            CmdRefresh = New DB2Command("select * from transportationcompany where transpoid like '%" & transportid.Text & "%'", DeliveryConnection)
            RdrRefresh = CmdRefresh.ExecuteReader
            Me.DataGridView2.Rows.Clear()
            While RdrRefresh.Read
                row = New String() {RdrRefresh.GetValue(0).ToString, RdrRefresh.GetString(1).Trim(), RdrRefresh.GetString(2).Trim()}
                Me.DataGridView2.Rows.Add(row)
            End While
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            If DataGridView1.Columns(e.ColumnIndex).Name = "clicked" Then
                Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
                SaleID.Text = row1.Cells("sale_id").Value
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView2.CellContentClick
        Try
            If DataGridView2.Columns(e.ColumnIndex).Name = "trans_select" Then
                Dim row1 As DataGridViewRow = DataGridView2.Rows(e.RowIndex)
                transpo_id.Text = row1.Cells("Id_transport").Value
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim deliverAdd As String
        Dim delivercdm As DB2Command
        Dim transport As DB2Parameter
        Dim sales As DB2Parameter
        Dim deliver As DB2Parameter
        Dim expectedDate As DB2Parameter
        Dim deliverStatus As DB2Parameter
        Dim DefaultStatus As String = "Undelivered"

        deliverAdd = "call DeliveryAdd(?,?,?,?,?)"
        delivercdm = New DB2Command(deliverAdd, DeliveryConnection)

        transport = delivercdm.Parameters.Add("@transport", DB2Type.Integer)
        transport.Direction = ParameterDirection.Input
        delivercdm.Parameters("@transport").Value = transpo_id.Text

        sales = delivercdm.Parameters.Add("@sales", DB2Type.Integer)
        sales.Direction = ParameterDirection.Input
        delivercdm.Parameters("@sales").Value = SaleID.Text

        deliver = delivercdm.Parameters.Add("@date", DB2Type.Date)
        deliver.Direction = ParameterDirection.Input
        delivercdm.Parameters("@date").Value = deliverdate.Text

        expectedDate = delivercdm.Parameters.Add("@n1", DB2Type.VarChar)
        expectedDate.Direction = ParameterDirection.Input
        delivercdm.Parameters("@n1").Value = date_pick.Text

        deliverStatus = delivercdm.Parameters.Add("@n2", DB2Type.VarChar)
        deliverStatus.Direction = ParameterDirection.Input
        delivercdm.Parameters("@n2").Value = DefaultStatus

        delivercdm.ExecuteNonQuery()
        MsgBox("Delivery Added Successfully...")
        transpo_id.Clear()
        SaleID.Clear()
        deliverdate.Clear()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        DisplayTransaction()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        DisplayTransport()
    End Sub

    Private Sub deliverdate_TextChanged(sender As Object, e As EventArgs) Handles deliverdate.TextChanged
        deliverdate.Text = DateTime.Now.ToString("yyyy/MM/dd")
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        Me.Close()
        Dashboard.Show()
    End Sub
End Class