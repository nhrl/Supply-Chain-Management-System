﻿Imports IBM.Data.DB2
Public Class CustomerForm
    Private CustFormConnection As DB2Connection
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub CustomerForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            CustFormConnection = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin;")
            CustFormConnection.Open()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim CustomerAdd As String
        Dim CusAddcmd As DB2Command
        Dim lastname As DB2Parameter
        Dim firstname As DB2Parameter
        Dim middle As DB2Parameter
        Dim contact As DB2Parameter
        Dim address As DB2Parameter


        CustomerAdd = "call  CustomerAdd(?,?,?,?,?)"
        CusAddcmd = New DB2Command(CustomerAdd, CustFormConnection)

        lastname = CusAddcmd.Parameters.Add("lastname", DB2Type.VarChar)
        lastname.Direction = ParameterDirection.Input
        CusAddcmd.Parameters("@lastname").Value = Me.custlast.Text

        firstname = CusAddcmd.Parameters.Add("@first", DB2Type.VarChar)
        firstname.Direction = ParameterDirection.Input
        CusAddcmd.Parameters("@first").Value = Me.custfname.Text

        middle = CusAddcmd.Parameters.Add("@middle", DB2Type.VarChar)
        middle.Direction = ParameterDirection.Input
        CusAddcmd.Parameters("@middle").Value = Me.custmname.Text

        contact = CusAddcmd.Parameters.Add("@contact", DB2Type.VarChar)
        contact.Direction = ParameterDirection.Input
        CusAddcmd.Parameters("@contact").Value = Me.custcontact.Text

        address = CusAddcmd.Parameters.Add("@address", DB2Type.VarChar)
        address.Direction = ParameterDirection.Input
        CusAddcmd.Parameters("@address").Value = Me.custaddress.Text

        MsgBox("New Record has been Added...")
        CusAddcmd.ExecuteNonQuery()
        Me.Close()
    End Sub
End Class