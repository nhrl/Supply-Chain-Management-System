﻿Imports IBM.Data.DB2
Public Class Customer
    Public CustomerID As String
    Public CustomerLastname As String
    Public CustomerFirstname As String
    Public MiddleName As String
    Public CustomerContact As String
    Public CustomerAddress As String


    Private CustomerConnection As DB2Connection
    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        CustomerForm.Show()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
        Dashboard.Show()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            If DataGridView1.Columns(e.ColumnIndex).Name = "Edit" Then
                Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
                CustomerID = row1.Cells("CustId").Value
                CustomerLastname = row1.Cells("cuslast").Value
                CustomerFirstname = row1.Cells("cusfname").Value
                MiddleName = row1.Cells("cusmname").Value
                CustomerContact = row1.Cells("cuscontact").Value
                CustomerAddress = row1.Cells("cusaddress").Value
                CustomerUpdate.Show()
            ElseIf DataGridView1.Columns(e.ColumnIndex).Name = "Delete" Then
                Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
                Dim delete As DB2Parameter
                Dim deleteData As String
                Dim cmd As DB2Command

                If MessageBox.Show(String.Format("Do you want to delete id:{0}", row1.Cells("CustId").Value), "Confirmation", MessageBoxButtons.OKCancel) = DialogResult.OK Then
                    deleteData = "call CustomerDelete(?)"
                    cmd = New DB2Command(deleteData, CustomerConnection)
                    delete = cmd.Parameters.Add("@delete", DB2Type.Integer)
                    delete.Direction = ParameterDirection.Input
                    cmd.Parameters("@delete").Value = row1.Cells("CustId").Value
                    cmd.ExecuteNonQuery()
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Customer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            CustomerConnection = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin;")
            CustomerConnection.Open()
            DisplayCustomer()
            Timer1.Start()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DisplayCustomer()
        Dim CmdRefresh As DB2Command
        Dim RdrRefresh As DB2DataReader

        Dim row As String()
        Try
            CmdRefresh = New DB2Command("select * from customer", CustomerConnection)
            RdrRefresh = CmdRefresh.ExecuteReader
            Me.DataGridView1.Rows.Clear()
            While RdrRefresh.Read
                row = New String() {RdrRefresh.GetValue(0).ToString, RdrRefresh.GetString(1).Trim(), RdrRefresh.GetString(2).Trim(), RdrRefresh.GetString(3).Trim(), RdrRefresh.GetString(4).Trim(), RdrRefresh.GetString(5).Trim}
                Me.DataGridView1.Rows.Add(row)
            End While
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        DisplayCustomer()
        Timer1.Start()
    End Sub
End Class