﻿Imports IBM.Data.DB2
Public Class LoginForm

    Private LogConn As Common.DbConnection
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles closebtn.Click
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles loginbtn.Click
        Dim CmdLogin As DB2Command
        Dim RdrLogin As DB2DataReader
        Dim empid As String
        Dim pass As String

        CmdLogin = New DB2Command("select * from employee where empid ='" & Me.empidtb.Text & "' and emppassword = '" & Me.passwordtb.Text & "'", LogConn)

        RdrLogin = CmdLogin.ExecuteReader
        If empidtb.Text = "" Then
            MsgBox("Enter ID", MsgBoxStyle.Critical)
        ElseIf passwordtb.Text = "" Then
            MsgBox("Enter Password", MsgBoxStyle.Critical)
        ElseIf RdrLogin.HasRows Then
            RdrLogin.Read()

            empid = RdrLogin.GetString(0)
            pass = RdrLogin.GetString(1)

            Me.empidtb.Text = empid
            Me.passwordtb.Text = pass

            Dashboard.Show()
            Dashboard.salesbtn.Enabled = True
            Dashboard.purchasebtn.Enabled = True
            Dashboard.deliverybtn.Enabled = True
            Dashboard.productbtn.Enabled = True
            Dashboard.customerbtn.Enabled = True
            Dashboard.supplierbtn.Enabled = True
            Dashboard.transpobtn.Enabled = True
            Dashboard.employeebtn.Enabled = True

        Else
            MessageBox.Show("Invalid User Credentials! Please Try Again")
        End If
        Me.empidtb.Clear()
        Me.passwordtb.Clear()


    End Sub

    Private Sub LoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'HIDE THE TEXT OF THE TextBox3 ON THE FIRST LOAD
        passwordtb.UseSystemPasswordChar = True
        Try
            LogConn = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin;")
            LogConn.Open()
        Catch ex As Exception
            MsgBox(ex.ToString)

        End Try
    End Sub
End Class
