﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EmployeeForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.emplast = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.empfirst = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.empmid = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.empcontact = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.empadd = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.empuser = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.empbday = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.emppass = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.empcivil = New System.Windows.Forms.ComboBox()
        Me.empsex = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(79, 50)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 17)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Lastname:"
        '
        'emplast
        '
        Me.emplast.Location = New System.Drawing.Point(176, 50)
        Me.emplast.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.emplast.Name = "emplast"
        Me.emplast.Size = New System.Drawing.Size(259, 22)
        Me.emplast.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(79, 96)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 17)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Firstname:"
        '
        'empfirst
        '
        Me.empfirst.Location = New System.Drawing.Point(176, 96)
        Me.empfirst.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.empfirst.Name = "empfirst"
        Me.empfirst.Size = New System.Drawing.Size(259, 22)
        Me.empfirst.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(61, 142)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(90, 17)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Middle Name"
        '
        'empmid
        '
        Me.empmid.Location = New System.Drawing.Point(176, 142)
        Me.empmid.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.empmid.Name = "empmid"
        Me.empmid.Size = New System.Drawing.Size(259, 22)
        Me.empmid.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(473, 193)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 17)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Contact:"
        '
        'empcontact
        '
        Me.empcontact.Location = New System.Drawing.Point(545, 186)
        Me.empcontact.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.empcontact.Name = "empcontact"
        Me.empcontact.Size = New System.Drawing.Size(259, 22)
        Me.empcontact.TabIndex = 8
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(88, 191)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 17)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Address:"
        '
        'empadd
        '
        Me.empadd.Location = New System.Drawing.Point(176, 191)
        Me.empadd.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.empadd.Name = "empadd"
        Me.empadd.Size = New System.Drawing.Size(259, 22)
        Me.empadd.TabIndex = 10
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(88, 321)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 17)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Username:"
        '
        'empuser
        '
        Me.empuser.Location = New System.Drawing.Point(176, 318)
        Me.empuser.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.empuser.Name = "empuser"
        Me.empuser.Size = New System.Drawing.Size(259, 22)
        Me.empuser.TabIndex = 12
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(473, 52)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(64, 17)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Birthday:"
        '
        'empbday
        '
        Me.empbday.Location = New System.Drawing.Point(545, 46)
        Me.empbday.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.empbday.Name = "empbday"
        Me.empbday.Size = New System.Drawing.Size(259, 22)
        Me.empbday.TabIndex = 14
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(455, 101)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(81, 17)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Civil Status:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(473, 318)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(73, 17)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Password:"
        '
        'emppass
        '
        Me.emppass.Location = New System.Drawing.Point(556, 318)
        Me.emppass.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.emppass.Name = "emppass"
        Me.emppass.Size = New System.Drawing.Size(259, 22)
        Me.emppass.TabIndex = 18
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(499, 139)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(35, 17)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Sex:"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.ForestGreen
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(297, 401)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(103, 41)
        Me.Button1.TabIndex = 27
        Me.Button1.Text = "Save"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(95, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Location = New System.Drawing.Point(545, 401)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(103, 41)
        Me.Button2.TabIndex = 28
        Me.Button2.Text = "Cancel"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'empcivil
        '
        Me.empcivil.FormattingEnabled = True
        Me.empcivil.Items.AddRange(New Object() {"Single", "Married", "Widowed", "Separated", "Divorced"})
        Me.empcivil.Location = New System.Drawing.Point(545, 97)
        Me.empcivil.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.empcivil.Name = "empcivil"
        Me.empcivil.Size = New System.Drawing.Size(259, 24)
        Me.empcivil.TabIndex = 29
        '
        'empsex
        '
        Me.empsex.FormattingEnabled = True
        Me.empsex.Items.AddRange(New Object() {"M", "F"})
        Me.empsex.Location = New System.Drawing.Point(545, 142)
        Me.empsex.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.empsex.Name = "empsex"
        Me.empsex.Size = New System.Drawing.Size(259, 24)
        Me.empsex.TabIndex = 30
        '
        'EmployeeForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(909, 490)
        Me.Controls.Add(Me.empsex)
        Me.Controls.Add(Me.empcivil)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.emppass)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.empbday)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.empuser)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.empadd)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.empcontact)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.empmid)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.empfirst)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.emplast)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "EmployeeForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Employee Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents emplast As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents empfirst As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents empmid As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents empcontact As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents empadd As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents empuser As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents empbday As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents emppass As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents empcivil As System.Windows.Forms.ComboBox
    Friend WithEvents empsex As System.Windows.Forms.ComboBox
End Class
