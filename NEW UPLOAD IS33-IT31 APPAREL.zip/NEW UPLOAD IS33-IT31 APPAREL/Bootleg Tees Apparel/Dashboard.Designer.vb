﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dashboard))
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.RectangleShape17 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape16 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape15 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape14 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape13 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.employeebtn = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.transpobtn = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.supplierbtn = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.customerbtn = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.productbtn = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape7 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape6 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape5 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape3 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.salesbtn = New System.Windows.Forms.Button()
        Me.purchasebtn = New System.Windows.Forms.Button()
        Me.deliverybtn = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.totalprod = New System.Windows.Forms.Label()
        Me.Customertotal = New System.Windows.Forms.Label()
        Me.supcount = New System.Windows.Forms.Label()
        Me.totalTransport = New System.Windows.Forms.Label()
        Me.EmployeeTotal = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.transport = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape17, Me.RectangleShape16, Me.RectangleShape15, Me.RectangleShape14, Me.RectangleShape13, Me.employeebtn, Me.transpobtn, Me.supplierbtn, Me.customerbtn, Me.productbtn, Me.RectangleShape7, Me.RectangleShape6, Me.RectangleShape5, Me.RectangleShape3, Me.RectangleShape2})
        Me.ShapeContainer1.Size = New System.Drawing.Size(972, 601)
        Me.ShapeContainer1.TabIndex = 0
        Me.ShapeContainer1.TabStop = False
        '
        'RectangleShape17
        '
        Me.RectangleShape17.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.RectangleShape17.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape17.BorderColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.RectangleShape17.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.RectangleShape17.Location = New System.Drawing.Point(633, 343)
        Me.RectangleShape17.Name = "RectangleShape17"
        Me.RectangleShape17.Size = New System.Drawing.Size(204, 44)
        '
        'RectangleShape16
        '
        Me.RectangleShape16.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.RectangleShape16.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape16.BorderColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.RectangleShape16.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.RectangleShape16.Location = New System.Drawing.Point(383, 343)
        Me.RectangleShape16.Name = "RectangleShape16"
        Me.RectangleShape16.Size = New System.Drawing.Size(204, 44)
        '
        'RectangleShape15
        '
        Me.RectangleShape15.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.RectangleShape15.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape15.BorderColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.RectangleShape15.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.RectangleShape15.Location = New System.Drawing.Point(755, 72)
        Me.RectangleShape15.Name = "RectangleShape15"
        Me.RectangleShape15.Size = New System.Drawing.Size(204, 44)
        '
        'RectangleShape14
        '
        Me.RectangleShape14.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.RectangleShape14.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape14.BorderColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.RectangleShape14.Cursor = System.Windows.Forms.Cursors.Default
        Me.RectangleShape14.Location = New System.Drawing.Point(506, 72)
        Me.RectangleShape14.Name = "RectangleShape14"
        Me.RectangleShape14.Size = New System.Drawing.Size(204, 44)
        '
        'RectangleShape13
        '
        Me.RectangleShape13.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.RectangleShape13.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape13.BorderColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.RectangleShape13.Cursor = System.Windows.Forms.Cursors.Default
        Me.RectangleShape13.Location = New System.Drawing.Point(252, 71)
        Me.RectangleShape13.Name = "RectangleShape13"
        Me.RectangleShape13.Size = New System.Drawing.Size(204, 44)
        '
        'employeebtn
        '
        Me.employeebtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.employeebtn.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.employeebtn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.employeebtn.CornerRadius = 20
        Me.employeebtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.employeebtn.Location = New System.Drawing.Point(633, 343)
        Me.employeebtn.Name = "employeebtn"
        Me.employeebtn.Size = New System.Drawing.Size(204, 250)
        '
        'transpobtn
        '
        Me.transpobtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.transpobtn.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.transpobtn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.transpobtn.CornerRadius = 20
        Me.transpobtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.transpobtn.Location = New System.Drawing.Point(383, 344)
        Me.transpobtn.Name = "transpobtn"
        Me.transpobtn.Size = New System.Drawing.Size(204, 250)
        '
        'supplierbtn
        '
        Me.supplierbtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.supplierbtn.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.supplierbtn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.supplierbtn.CornerRadius = 20
        Me.supplierbtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.supplierbtn.Location = New System.Drawing.Point(755, 72)
        Me.supplierbtn.Name = "supplierbtn"
        Me.supplierbtn.Size = New System.Drawing.Size(204, 250)
        '
        'customerbtn
        '
        Me.customerbtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.customerbtn.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.customerbtn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.customerbtn.CornerRadius = 20
        Me.customerbtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.customerbtn.Location = New System.Drawing.Point(506, 73)
        Me.customerbtn.Name = "customerbtn"
        Me.customerbtn.Size = New System.Drawing.Size(204, 250)
        '
        'productbtn
        '
        Me.productbtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.productbtn.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.productbtn.BorderColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.productbtn.CornerRadius = 20
        Me.productbtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.productbtn.Location = New System.Drawing.Point(252, 71)
        Me.productbtn.Name = "productbtn"
        Me.productbtn.Size = New System.Drawing.Size(204, 250)
        '
        'RectangleShape7
        '
        Me.RectangleShape7.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.RectangleShape7.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape7.BorderColor = System.Drawing.Color.Black
        Me.RectangleShape7.BorderWidth = 3
        Me.RectangleShape7.Location = New System.Drawing.Point(-2, -1)
        Me.RectangleShape7.Name = "RectangleShape7"
        Me.RectangleShape7.Size = New System.Drawing.Size(974, 46)
        '
        'RectangleShape6
        '
        Me.RectangleShape6.BackColor = System.Drawing.Color.Black
        Me.RectangleShape6.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape6.Location = New System.Drawing.Point(-2, 160)
        Me.RectangleShape6.Name = "RectangleShape6"
        Me.RectangleShape6.Size = New System.Drawing.Size(227, 42)
        '
        'RectangleShape5
        '
        Me.RectangleShape5.BackColor = System.Drawing.Color.Black
        Me.RectangleShape5.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape5.Location = New System.Drawing.Point(-2, 104)
        Me.RectangleShape5.Name = "RectangleShape5"
        Me.RectangleShape5.Size = New System.Drawing.Size(224, 42)
        '
        'RectangleShape3
        '
        Me.RectangleShape3.BackColor = System.Drawing.Color.Black
        Me.RectangleShape3.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape3.Location = New System.Drawing.Point(-1, 49)
        Me.RectangleShape3.Name = "RectangleShape3"
        Me.RectangleShape3.Size = New System.Drawing.Size(236, 42)
        '
        'RectangleShape2
        '
        Me.RectangleShape2.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.RectangleShape2.BackStyle = Microsoft.VisualBasic.PowerPacks.BackStyle.Opaque
        Me.RectangleShape2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.RectangleShape2.Location = New System.Drawing.Point(-1, 47)
        Me.RectangleShape2.Name = "RectangleShape2"
        Me.RectangleShape2.Size = New System.Drawing.Size(237, 566)
        '
        'salesbtn
        '
        Me.salesbtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.salesbtn.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.salesbtn.FlatAppearance.BorderSize = 0
        Me.salesbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.salesbtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.salesbtn.Location = New System.Drawing.Point(12, 49)
        Me.salesbtn.Name = "salesbtn"
        Me.salesbtn.Size = New System.Drawing.Size(225, 43)
        Me.salesbtn.TabIndex = 2
        Me.salesbtn.Text = "Sale Transaction"
        Me.salesbtn.UseVisualStyleBackColor = False
        '
        'purchasebtn
        '
        Me.purchasebtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.purchasebtn.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.purchasebtn.FlatAppearance.BorderSize = 0
        Me.purchasebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.purchasebtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.purchasebtn.Location = New System.Drawing.Point(12, 104)
        Me.purchasebtn.Name = "purchasebtn"
        Me.purchasebtn.Size = New System.Drawing.Size(224, 43)
        Me.purchasebtn.TabIndex = 3
        Me.purchasebtn.Text = "Purchase Transaction"
        Me.purchasebtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.purchasebtn.UseVisualStyleBackColor = False
        '
        'deliverybtn
        '
        Me.deliverybtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.deliverybtn.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.deliverybtn.FlatAppearance.BorderSize = 0
        Me.deliverybtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.deliverybtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deliverybtn.Location = New System.Drawing.Point(12, 160)
        Me.deliverybtn.Name = "deliverybtn"
        Me.deliverybtn.Size = New System.Drawing.Size(225, 43)
        Me.deliverybtn.TabIndex = 4
        Me.deliverybtn.Text = "Delivery"
        Me.deliverybtn.UseVisualStyleBackColor = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(27, 58)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(28, 24)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 6
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(27, 113)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(28, 24)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 7
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(27, 169)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(28, 24)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 8
        Me.PictureBox4.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(312, 86)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 20)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Product"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(567, 86)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 20)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Customer"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(819, 86)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 20)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Supplier"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(383, 355)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(205, 20)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Transportation Company"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(195, Byte), Integer))
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(694, 355)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(87, 20)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Employee"
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.PictureBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(307, 157)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(89, 81)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 14
        Me.PictureBox5.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.PictureBox6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), System.Drawing.Image)
        Me.PictureBox6.Location = New System.Drawing.Point(564, 157)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(89, 81)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 15
        Me.PictureBox6.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.PictureBox7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), System.Drawing.Image)
        Me.PictureBox7.Location = New System.Drawing.Point(814, 157)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(89, 81)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 16
        Me.PictureBox7.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.PictureBox8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), System.Drawing.Image)
        Me.PictureBox8.Location = New System.Drawing.Point(443, 430)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(89, 81)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox8.TabIndex = 17
        Me.PictureBox8.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.PictureBox9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(692, 430)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(89, 81)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox9.TabIndex = 18
        Me.PictureBox9.TabStop = False
        '
        'totalprod
        '
        Me.totalprod.AutoSize = True
        Me.totalprod.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.totalprod.Cursor = System.Windows.Forms.Cursors.Hand
        Me.totalprod.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalprod.ForeColor = System.Drawing.Color.White
        Me.totalprod.Location = New System.Drawing.Point(338, 280)
        Me.totalprod.Name = "totalprod"
        Me.totalprod.Size = New System.Drawing.Size(19, 20)
        Me.totalprod.TabIndex = 19
        Me.totalprod.Text = "3"
        '
        'Customertotal
        '
        Me.Customertotal.AutoSize = True
        Me.Customertotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.Customertotal.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Customertotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Customertotal.ForeColor = System.Drawing.Color.White
        Me.Customertotal.Location = New System.Drawing.Point(601, 280)
        Me.Customertotal.Name = "Customertotal"
        Me.Customertotal.Size = New System.Drawing.Size(19, 20)
        Me.Customertotal.TabIndex = 20
        Me.Customertotal.Text = "3"
        '
        'supcount
        '
        Me.supcount.AutoSize = True
        Me.supcount.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.supcount.Cursor = System.Windows.Forms.Cursors.Hand
        Me.supcount.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.supcount.ForeColor = System.Drawing.Color.White
        Me.supcount.Location = New System.Drawing.Point(849, 280)
        Me.supcount.Name = "supcount"
        Me.supcount.Size = New System.Drawing.Size(19, 20)
        Me.supcount.TabIndex = 21
        Me.supcount.Text = "3"
        '
        'totalTransport
        '
        Me.totalTransport.AutoSize = True
        Me.totalTransport.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.totalTransport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.totalTransport.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalTransport.ForeColor = System.Drawing.Color.White
        Me.totalTransport.Location = New System.Drawing.Point(477, 548)
        Me.totalTransport.Name = "totalTransport"
        Me.totalTransport.Size = New System.Drawing.Size(0, 20)
        Me.totalTransport.TabIndex = 22
        '
        'EmployeeTotal
        '
        Me.EmployeeTotal.AutoSize = True
        Me.EmployeeTotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.EmployeeTotal.Cursor = System.Windows.Forms.Cursors.Hand
        Me.EmployeeTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmployeeTotal.ForeColor = System.Drawing.Color.White
        Me.EmployeeTotal.Location = New System.Drawing.Point(728, 548)
        Me.EmployeeTotal.Name = "EmployeeTotal"
        Me.EmployeeTotal.Size = New System.Drawing.Size(19, 20)
        Me.EmployeeTotal.TabIndex = 23
        Me.EmployeeTotal.Text = "3"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(23, 9)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(182, 20)
        Me.Label11.TabIndex = 24
        Me.Label11.Text = "Bootleg Tees Apparel"
        '
        'PictureBox10
        '
        Me.PictureBox10.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.PictureBox10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Image)
        Me.PictureBox10.Location = New System.Drawing.Point(924, 9)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(36, 29)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox10.TabIndex = 26
        Me.PictureBox10.TabStop = False
        '
        'transport
        '
        Me.transport.AutoSize = True
        Me.transport.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.transport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.transport.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.transport.ForeColor = System.Drawing.Color.White
        Me.transport.Location = New System.Drawing.Point(477, 548)
        Me.transport.Name = "transport"
        Me.transport.Size = New System.Drawing.Size(19, 20)
        Me.transport.TabIndex = 27
        Me.transport.Text = "3"
        '
        'Timer1
        '
        '
        'Dashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gainsboro
        Me.ClientSize = New System.Drawing.Size(972, 601)
        Me.Controls.Add(Me.transport)
        Me.Controls.Add(Me.PictureBox10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.EmployeeTotal)
        Me.Controls.Add(Me.totalTransport)
        Me.Controls.Add(Me.supcount)
        Me.Controls.Add(Me.Customertotal)
        Me.Controls.Add(Me.totalprod)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.deliverybtn)
        Me.Controls.Add(Me.purchasebtn)
        Me.Controls.Add(Me.salesbtn)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Name = "Dashboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Dashboard"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents RectangleShape2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape6 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape5 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape3 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents salesbtn As System.Windows.Forms.Button
    Friend WithEvents purchasebtn As System.Windows.Forms.Button
    Friend WithEvents deliverybtn As System.Windows.Forms.Button
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents employeebtn As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents transpobtn As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents supplierbtn As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents customerbtn As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents productbtn As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape7 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape17 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape16 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape15 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape14 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape13 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents totalprod As System.Windows.Forms.Label
    Friend WithEvents Customertotal As System.Windows.Forms.Label
    Friend WithEvents supcount As System.Windows.Forms.Label
    Friend WithEvents totalTransport As System.Windows.Forms.Label
    Friend WithEvents EmployeeTotal As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents transport As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
End Class
