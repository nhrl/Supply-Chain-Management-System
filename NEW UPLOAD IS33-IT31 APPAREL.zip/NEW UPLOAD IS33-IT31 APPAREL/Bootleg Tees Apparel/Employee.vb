﻿Imports IBM.Data.DB2
Public Class Employee
    Public EmployeeId As String
    Public EmployeeLast As String
    Public EmplyeeFirst As String
    Public EmployeeMiddle As String
    Public EmployeeContact As String
    Public EmployeeAddress As String
    Public EmployeeUser As String
    Public EmployeePass As String
    Public EmployeeBday As String
    Public EmployeeCivilStat As String
    Public EmployeeSex As String

    Private EmployeeConnection As DB2Connection
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Close()
        Dashboard.Show()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        EmployeeForm.Show()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            If DataGridView1.Columns(e.ColumnIndex).Name = "empedit" Then
                Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
                EmployeeId = row1.Cells("empid").Value
                EmployeeLast = row1.Cells("emplast").Value
                EmplyeeFirst = row1.Cells("empfirst").Value
                EmployeeMiddle = row1.Cells("empmid").Value
                EmployeeContact = row1.Cells("empcontact").Value
                EmployeeAddress = row1.Cells("empadd").Value
                EmployeeUser = row1.Cells("empuser").Value
                EmployeePass = row1.Cells("emppass").Value
                EmployeeBday = row1.Cells("empbday").Value
                EmployeeCivilStat = row1.Cells("empcivil").Value
                EmployeeSex = row1.Cells("empsex").Value
                EmployeeUpdate.Show()
            ElseIf DataGridView1.Columns(e.ColumnIndex).Name = "Delete" Then
                Dim row1 As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
                Dim delete As DB2Parameter
                Dim deleteData As String
                Dim cmd As DB2Command

                If MessageBox.Show(String.Format("Do you want to delete id:{0}", row1.Cells("empid").Value), "Confirmation", MessageBoxButtons.OKCancel) = DialogResult.OK Then
                    deleteData = "call  EmployeeDelete(?)"
                    cmd = New DB2Command(deleteData, EmployeeConnection)
                    delete = cmd.Parameters.Add("@delete", DB2Type.Integer)
                    delete.Direction = ParameterDirection.Input
                    cmd.Parameters("@delete").Value = row1.Cells("empid").Value
                    cmd.ExecuteNonQuery()
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Employee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            EmployeeConnection = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin;")
            EmployeeConnection.Open()
            DisplayEmployee()
            Timer1.Start()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DisplayEmployee()
        Dim CmdRefresh As DB2Command
        Dim RdrRefresh As DB2DataReader

        Dim row As String()
        Try
            CmdRefresh = New DB2Command("select * from Employee", EmployeeConnection)
            RdrRefresh = CmdRefresh.ExecuteReader
            Me.DataGridView1.Rows.Clear()
            While RdrRefresh.Read
                row = New String() {RdrRefresh.GetValue(0).ToString, RdrRefresh.GetString(1).Trim(), RdrRefresh.GetString(2).Trim(), RdrRefresh.GetString(3).Trim(), RdrRefresh.GetString(4).Trim(), RdrRefresh.GetString(5).Trim(), RdrRefresh.GetString(6).Trim(), RdrRefresh.GetString(7).Trim(), RdrRefresh.GetString(8).Trim(), RdrRefresh.GetString(9).Trim(), RdrRefresh.GetChar(10).ToString}
                Me.DataGridView1.Rows.Add(row)
            End While
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        DisplayEmployee()
        Timer1.Start()
    End Sub
End Class