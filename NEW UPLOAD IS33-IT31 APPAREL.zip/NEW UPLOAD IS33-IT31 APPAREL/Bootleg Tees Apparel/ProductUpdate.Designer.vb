﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.text3 = New System.Windows.Forms.Label()
        Me.prodquan = New System.Windows.Forms.TextBox()
        Me.text2 = New System.Windows.Forms.Label()
        Me.prodprice = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.text1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.prodid = New System.Windows.Forms.TextBox()
        Me.prodsex = New System.Windows.Forms.ComboBox()
        Me.prodsize = New System.Windows.Forms.ComboBox()
        Me.prodname = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(95, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Location = New System.Drawing.Point(432, 276)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(103, 41)
        Me.Button2.TabIndex = 27
        Me.Button2.Text = "Cancel"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.ForestGreen
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(229, 276)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(103, 41)
        Me.Button1.TabIndex = 26
        Me.Button1.Text = "Update"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'text3
        '
        Me.text3.AutoSize = True
        Me.text3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.text3.Location = New System.Drawing.Point(15, 222)
        Me.text3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.text3.Name = "text3"
        Me.text3.Size = New System.Drawing.Size(122, 18)
        Me.text3.TabIndex = 25
        Me.text3.Text = "Product Quantity:"
        '
        'prodquan
        '
        Me.prodquan.Location = New System.Drawing.Point(155, 222)
        Me.prodquan.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.prodquan.Name = "prodquan"
        Me.prodquan.Size = New System.Drawing.Size(219, 22)
        Me.prodquan.TabIndex = 24
        '
        'text2
        '
        Me.text2.AutoSize = True
        Me.text2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.text2.Location = New System.Drawing.Point(15, 169)
        Me.text2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.text2.Name = "text2"
        Me.text2.Size = New System.Drawing.Size(102, 18)
        Me.text2.TabIndex = 23
        Me.text2.Text = "Product Price:"
        '
        'prodprice
        '
        Me.prodprice.Location = New System.Drawing.Point(141, 169)
        Me.prodprice.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.prodprice.Name = "prodprice"
        Me.prodprice.Size = New System.Drawing.Size(219, 22)
        Me.prodprice.TabIndex = 22
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(375, 110)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(97, 18)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Product Size:"
        '
        'text1
        '
        Me.text1.AutoSize = True
        Me.text1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.text1.Location = New System.Drawing.Point(15, 108)
        Me.text1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.text1.Name = "text1"
        Me.text1.Size = New System.Drawing.Size(108, 18)
        Me.text1.TabIndex = 19
        Me.text1.Text = "Product Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(340, 49)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(129, 18)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Product Sex Type:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(15, 49)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 18)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "Product ID:"
        '
        'prodid
        '
        Me.prodid.Location = New System.Drawing.Point(112, 48)
        Me.prodid.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.prodid.Name = "prodid"
        Me.prodid.Size = New System.Drawing.Size(219, 22)
        Me.prodid.TabIndex = 14
        '
        'prodsex
        '
        Me.prodsex.FormattingEnabled = True
        Me.prodsex.Items.AddRange(New Object() {"M", "F"})
        Me.prodsex.Location = New System.Drawing.Point(488, 47)
        Me.prodsex.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.prodsex.Name = "prodsex"
        Me.prodsex.Size = New System.Drawing.Size(219, 24)
        Me.prodsex.TabIndex = 28
        '
        'prodsize
        '
        Me.prodsize.FormattingEnabled = True
        Me.prodsize.Items.AddRange(New Object() {"XS", "S", "M", "L", "XL"})
        Me.prodsize.Location = New System.Drawing.Point(488, 110)
        Me.prodsize.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.prodsize.Name = "prodsize"
        Me.prodsize.Size = New System.Drawing.Size(219, 24)
        Me.prodsize.TabIndex = 29
        '
        'prodname
        '
        Me.prodname.FormattingEnabled = True
        Me.prodname.Items.AddRange(New Object() {"Bootleg", "Vintage", "Overruns"})
        Me.prodname.Location = New System.Drawing.Point(131, 107)
        Me.prodname.Margin = New System.Windows.Forms.Padding(4)
        Me.prodname.Name = "prodname"
        Me.prodname.Size = New System.Drawing.Size(219, 24)
        Me.prodname.TabIndex = 30
        '
        'ProductUpdate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(137, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(120, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(724, 366)
        Me.Controls.Add(Me.prodname)
        Me.Controls.Add(Me.prodsize)
        Me.Controls.Add(Me.prodsex)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.text3)
        Me.Controls.Add(Me.prodquan)
        Me.Controls.Add(Me.text2)
        Me.Controls.Add(Me.prodprice)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.text1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.prodid)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "ProductUpdate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Product Update"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents text3 As System.Windows.Forms.Label
    Friend WithEvents prodquan As System.Windows.Forms.TextBox
    Friend WithEvents text2 As System.Windows.Forms.Label
    Friend WithEvents prodprice As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents text1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents prodid As System.Windows.Forms.TextBox
    Friend WithEvents prodsex As System.Windows.Forms.ComboBox
    Friend WithEvents prodsize As System.Windows.Forms.ComboBox
    Friend WithEvents prodname As System.Windows.Forms.ComboBox
End Class
