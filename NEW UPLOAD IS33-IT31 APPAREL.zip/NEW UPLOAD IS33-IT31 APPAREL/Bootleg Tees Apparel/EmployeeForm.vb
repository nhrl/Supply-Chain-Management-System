﻿Imports IBM.Data.DB2
Public Class EmployeeForm
    Private EmployeeFromConn As DB2Connection
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub EmployeeForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            EmployeeFromConn = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin;")
            EmployeeFromConn.Open()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim EmployeeAdd As String
        Dim Addcmd As DB2Command
        Dim emplastname As DB2Parameter
        Dim empfirstname As DB2Parameter
        Dim empmiddle As DB2Parameter
        Dim empcontact As DB2Parameter
        Dim empaddress As DB2Parameter
        Dim empUser As DB2Parameter
        Dim empPass As DB2Parameter
        Dim bday As DB2Parameter
        Dim civil As DB2Parameter
        Dim sex As DB2Parameter

        EmployeeAdd = "call EmployeeAdd(?,?,?,?,?,?,?,?,?,?)"
        Addcmd = New DB2Command(EmployeeAdd, EmployeeFromConn)

        emplastname = Addcmd.Parameters.Add("lastname", DB2Type.VarChar)
        emplastname.Direction = ParameterDirection.Input
        Addcmd.Parameters("@lastname").Value = Me.emplast.Text

        empfirstname = Addcmd.Parameters.Add("@first", DB2Type.VarChar)
        empfirstname.Direction = ParameterDirection.Input
        Addcmd.Parameters("@first").Value = Me.empfirst.Text

        empmiddle = Addcmd.Parameters.Add("@middle", DB2Type.VarChar)
        empmiddle.Direction = ParameterDirection.Input
        Addcmd.Parameters("@middle").Value = Me.empmid.Text

        empcontact = Addcmd.Parameters.Add("@contact", DB2Type.VarChar)
        empcontact.Direction = ParameterDirection.Input
        Addcmd.Parameters("@contact").Value = Me.empcontact.Text

        empaddress = Addcmd.Parameters.Add("@address", DB2Type.VarChar)
        empaddress.Direction = ParameterDirection.Input
        Addcmd.Parameters("@address").Value = Me.empadd.Text

        empUser = Addcmd.Parameters.Add("@user", DB2Type.VarChar)
        empUser.Direction = ParameterDirection.Input
        Addcmd.Parameters("@user").Value = Me.empuser.Text

        empPass = Addcmd.Parameters.Add("@pass", DB2Type.VarChar)
        empPass.Direction = ParameterDirection.Input
        Addcmd.Parameters("@pass").Value = Me.emppass.Text

        bday = Addcmd.Parameters.Add("@bday", DB2Type.VarChar)
        bday.Direction = ParameterDirection.Input
        Addcmd.Parameters("@bday").Value = Me.empbday.Text

        civil = Addcmd.Parameters.Add("@civil", DB2Type.VarChar)
        civil.Direction = ParameterDirection.Input
        Addcmd.Parameters("@civil").Value = Me.empcivil.Text

        sex = Addcmd.Parameters.Add("@sex", DB2Type.Char)
        sex.Direction = ParameterDirection.Input
        Addcmd.Parameters("@sex").Value = Me.empsex.Text

        MsgBox("New Record has been Added...")
        Addcmd.ExecuteNonQuery()
        Me.Close()
    End Sub
End Class
