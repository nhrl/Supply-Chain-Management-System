﻿Imports IBM.Data.DB2
Public Class CustomerUpdate
    Private CustomerUpdateConn As DB2Connection
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub CustomerUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            CustomerUpdateConn = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin;")
            CustomerUpdateConn.Open()
            custid.Text = Customer.CustomerID
            custid.Enabled = False
            cusfname.Text = Customer.CustomerFirstname
            custmname.Text = Customer.MiddleName
            custlast.Text = Customer.CustomerLastname
            custadd.Text = Customer.CustomerAddress
            cuscontact.Text = Customer.CustomerContact
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim CustomerUpdate As String
        Dim CusAddcmd As DB2Command
        Dim updatecusid As DB2Parameter
        Dim lastname As DB2Parameter
        Dim firstname As DB2Parameter
        Dim middle As DB2Parameter
        Dim contact As DB2Parameter
        Dim address As DB2Parameter


        CustomerUpdate = "call CustomerUpdate (?,?,?,?,?,?)"
        CusAddcmd = New DB2Command(CustomerUpdate, CustomerUpdateConn)
        updatecusid = CusAddcmd.Parameters.Add("@id", DB2Type.Integer)
        updatecusid.Direction = ParameterDirection.Input
        CusAddcmd.Parameters("@id").Value = Me.custid.Text

        lastname = CusAddcmd.Parameters.Add("@lastname", DB2Type.VarChar)
        lastname.Direction = ParameterDirection.Input
        CusAddcmd.Parameters("@lastname").Value = Me.custlast.Text

        firstname = CusAddcmd.Parameters.Add("@first", DB2Type.VarChar)
        firstname.Direction = ParameterDirection.Input
        CusAddcmd.Parameters("@first").Value = Me.cusfname.Text

        middle = CusAddcmd.Parameters.Add("@middle", DB2Type.VarChar)
        middle.Direction = ParameterDirection.Input
        CusAddcmd.Parameters("@middle").Value = Me.custmname.Text

        contact = CusAddcmd.Parameters.Add("@contact", DB2Type.VarChar)
        contact.Direction = ParameterDirection.Input
        CusAddcmd.Parameters("@contact").Value = Me.cuscontact.Text

        address = CusAddcmd.Parameters.Add("@address", DB2Type.VarChar)
        address.Direction = ParameterDirection.Input
        CusAddcmd.Parameters("@address").Value = Me.custadd.Text

        CusAddcmd.ExecuteNonQuery()
        MsgBox("Record Updated Successfully...")
        Me.Close()
    End Sub
End Class