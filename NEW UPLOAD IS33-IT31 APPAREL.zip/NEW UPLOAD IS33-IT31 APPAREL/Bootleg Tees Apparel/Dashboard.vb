﻿Imports IBM.Data.DB2
Public Class Dashboard
    Private Dashboardconnection As DB2Connection
    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles PictureBox10.Click
        Me.Close()
    End Sub

    Private Sub RectangleShape8_Click(sender As Object, e As EventArgs) Handles productbtn.Click
        Product.Show()
        Me.Hide()
    End Sub

    Private Sub RectangleShape9_Click(sender As Object, e As EventArgs) Handles customerbtn.Click
        Customer.Show()
        Me.Hide()
    End Sub

    Private Sub RectangleShape10_Click(sender As Object, e As EventArgs) Handles supplierbtn.Click
        Supplier.Show()
        Me.Hide()
    End Sub

    Private Sub RectangleShape11_Click(sender As Object, e As EventArgs) Handles transpobtn.Click
        Transportation.Show()
        Me.Hide()
    End Sub

    Private Sub RectangleShape12_Click(sender As Object, e As EventArgs) Handles employeebtn.Click
        Employee.Show()
        Me.Hide()
    End Sub

    Private Sub Dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
        Try
            Dashboardconnection = New DB2Connection("server = localhost; database = apparel;" + "uid = db2admin; password = db2admin")
            Dashboardconnection.Open()
            TransportCount()
            SupplierCount()
            ProductCount()
            CustomerCount()
            EmployeeCount()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub TransportCount()
        Dim transpo_stmt As String
        Dim totalCmd As DB2Command
        Dim totalTransport As String

        transpo_stmt = "select count(*) from TransportationCompany"
        totalCmd = New DB2Command(transpo_stmt, Dashboardconnection)
        totalTransport = totalCmd.ExecuteScalar()

        transport.Text = totalTransport

    End Sub

    Private Sub SupplierCount()
        Dim supplier_stmt As String
        Dim totalcmd As DB2Command
        Dim totalsupplier As String

        supplier_stmt = "select count(*) from supplier"
        totalcmd = New DB2Command(supplier_stmt, Dashboardconnection)
        totalsupplier = totalcmd.ExecuteScalar

        supcount.Text = totalsupplier
    End Sub

    Private Sub ProductCount()
        Dim product_stmt As String
        Dim totalcmd As DB2Command
        Dim totalproduct As String

        product_stmt = "select count(*) from product"
        totalcmd = New DB2Command(product_stmt, Dashboardconnection)
        totalproduct = totalcmd.ExecuteScalar

        totalprod.Text = totalproduct
    End Sub

    Private Sub CustomerCount()
        Dim Customer_stmt As String
        Dim totalcmd As DB2Command
        Dim totalCustomer As String

        Customer_stmt = "select count(*) from Customer"
        totalcmd = New DB2Command(Customer_stmt, Dashboardconnection)
        totalCustomer = totalcmd.ExecuteScalar

        Customertotal.Text = totalCustomer
    End Sub

    Private Sub EmployeeCount()
        Dim Employee_stmt As String
        Dim totalcmd As DB2Command
        Dim totalEmployee As String

        Employee_stmt = "select count(*) from Employee"
        totalcmd = New DB2Command(Employee_stmt, Dashboardconnection)
        totalEmployee = totalcmd.ExecuteScalar

        EmployeeTotal.Text = totalEmployee
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        TransportCount()
        SupplierCount()
        ProductCount()
        CustomerCount()
        EmployeeCount()
        Timer1.Start()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles purchasebtn.Click
        PurchaseTransaction.Show()
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles salesbtn.Click
        SaleTransaction.Show()
        Me.Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles deliverybtn.Click
        Delivery.Show()
        Me.Close()
    End Sub
End Class